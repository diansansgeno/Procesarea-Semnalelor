set.seed(241)
N <- 10000
zar <- sample(1:6, N, replace = TRUE)
A <- zar %% 2 == 0
B <- zar > 3
n <- seq_len(N)
nr_B <- cumsum(B)
p_cond <- rep(NA_real_, N)
ok <- nr_B > 0
p_cond[ok] <- cumsum(A & B)[ok] / nr_B[ok]

par(mfrow = c(1, 2), mar = c(4, 4, 2, 1))
plot(n, cumsum(A) / n, type = "l", ylim = c(0, 1),
     col = "#A33278", xlab = "Numar de aruncari",
     ylab = "Frecventa relativa", main = "P(A) = 1/2")
abline(h = 1/2, lty = 2, col = "gray40")
plot(n, p_cond, type = "l", ylim = c(0, 1),
     col = "#72235E", xlab = "Numar de aruncari",
     ylab = "Frecventa conditionata", main = "P(A | B) = 2/3")
abline(h = 2/3, lty = 2, col = "gray40")
par(mfrow = c(1, 1))
print(c(P_A = mean(A), P_A_dat_B = mean(A[B])))
