set.seed(243)
N <- 100000
sursa <- sample(1:3, N, replace = TRUE,
                prob = c(0.50, 0.30, 0.20))
rate <- c(0.01, 0.02, 0.05)
eroare <- runif(N) < rate[sursa]

initial <- c(0.50, 0.30, 0.20)
posterior <- initial * rate / sum(initial * rate)
estimat <- tabulate(sursa[eroare], nbins = 3) / sum(eroare)
rezultat <- rbind(Initial = initial,
                  Bayes = posterior, Simulare = estimat)
colnames(rezultat) <- c("S1", "S2", "S3")
print(round(rezultat, 4))
print(c(P_eroare = mean(eroare),
        P_S1_fara_eroare = mean(sursa[!eroare] == 1)))

par(mar = c(4, 4, 2, 1))
barplot(rezultat, beside = TRUE, ylim = c(0, 0.65),
        col = c("#D9B6CD", "#A33278", "#72235E"),
        xlab = "Serviciu", ylab = "Probabilitate",
        legend.text = rownames(rezultat),
        args.legend = list(x = "topright", bty = "n"))
