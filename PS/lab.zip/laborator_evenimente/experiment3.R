p <- seq(0.001, 0.20, length.out = 500)
s <- 0.95
f <- 0.04
unul <- p * s / (p * s + (1 - p) * f)
doi <- p * s^2 / (p * s^2 + (1 - p) * f^2)

par(mar = c(4, 4, 2, 1))
plot(100 * p, unul, type = "l", lwd = 2,
     col = "#A33278", ylim = c(0, 1),
     xlab = "Sesiuni care sunt atacuri (%)",
     ylab = "Probabilitatea unui atac dupa alerta")
lines(100 * p, doi, lwd = 2, col = "#72235E", lty = 2)
abline(v = 2, lty = 3, col = "gray50")
legend("bottomright", c("O alerta", "Doua alerte"),
       col = c("#A33278", "#72235E"),
       lty = c(1, 2), lwd = 2, bty = "n")

p0 <- 0.02
print(c(o_alerta = p0*s / (p0*s + (1-p0)*f),
        doua_alerte = p0*s^2 / (p0*s^2 + (1-p0)*f^2)))
