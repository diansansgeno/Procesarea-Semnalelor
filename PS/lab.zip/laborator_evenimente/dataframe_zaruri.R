omega <- expand.grid(zar1 = 1:6, zar2 = 1:6)
omega$id <- seq_len(nrow(omega))
omega$suma <- with(omega, zar1 + zar2)
omega$produs <- with(omega, zar1 * zar2)
omega$A <- omega$suma <= 5
omega$B <- omega$produs %in% (1:6)^2
omega <- omega[c("id", "zar1", "zar2", "suma", "produs", "A", "B")]

A_df <- subset(omega, A)
B_df <- subset(omega, B)
AB_df <- subset(B_df, A)
print(B_df, row.names = FALSE)
print(AB_df, row.names = FALSE)

probabilitati <- c(
  P_A = nrow(A_df) / nrow(omega),
  P_B = nrow(B_df) / nrow(omega),
  P_AB = nrow(AB_df) / nrow(omega),
  P_A_dat_B = nrow(AB_df) / nrow(B_df),
  P_B_dat_A = nrow(AB_df) / nrow(A_df)
)
print(probabilitati)
print(mean(B_df$A))
if (interactive()) View(B_df)
