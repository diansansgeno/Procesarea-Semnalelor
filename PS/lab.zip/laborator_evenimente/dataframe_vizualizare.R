omega <- expand.grid(zar1 = 1:6, zar2 = 1:6)
omega$A <- with(omega, zar1 + zar2 <= 5)
omega$B <- with(omega, (zar1 * zar2) %in% (1:6)^2)
B_df <- subset(omega, B)
B_df$id <- as.integer(rownames(B_df))
par(mfrow = c(1, 2), mar = c(4, 4, 3, 1))
culori <- ifelse(omega$B, "#D9B6CD", "#E6E6E6")
culori[omega$A & omega$B] <- "#A33278"
plot(omega$zar1, omega$zar2, pch = 22, cex = 2.7,
     bg = culori, col = "#72235E", xlim = c(0.5, 6.5),
     ylim = c(0.5, 6.5), xaxt = "n", yaxt = "n", asp = 1,
     xlab = "Primul zar", ylab = "Al doilea zar",
     main = "omega: 36 de randuri")
axis(1, at = 1:6)
axis(2, at = 1:6, las = 1)
text(omega$zar1, omega$zar2, seq_len(nrow(omega)), cex = 0.7)
par(mar = c(1, 1, 3, 1))
plot.new()
plot.window(xlim = c(0, 4), ylim = c(0, 10))
title("B_df: cele 8 randuri pastrate")
rect(0, 8.5, 4, 9.5, col = "#F6EDF3", border = NA)
text(c(0.4, 1.4, 2.4, 3.4), 9,
     c("id", "zar1", "zar2", "A"), font = 2)
for (i in seq_len(nrow(B_df))) {
  y <- 9 - i
  bg <- if (B_df$A[i]) "#A33278" else "#D9B6CD"
  rect(0, y - 0.45, 4, y + 0.45, col = bg, border = "white")
  text(c(0.4, 1.4, 2.4, 3.4), y,
       c(B_df$id[i], B_df$zar1[i], B_df$zar2[i],
         as.character(B_df$A[i])),
       col = if (B_df$A[i]) "white" else "#302B32")
}
par(mfrow = c(1, 1))
