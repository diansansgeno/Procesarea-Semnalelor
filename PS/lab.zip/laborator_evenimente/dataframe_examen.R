date <- data.frame(
  id = 1:100,
  gen = rep(c("M", "F", "M", "F"), c(24, 36, 16, 24)),
  promovat = rep(c(TRUE, FALSE), c(60, 40))
)
date$A <- date$promovat
date$B <- date$gen == "M"
B_df <- subset(date, B)
AB_df <- subset(B_df, A)

tabel <- with(date, table(gen, promovat))
print(tabel)
print(c(P_A = mean(date$A), P_B = mean(date$B),
        P_AB = mean(date$A & date$B),
        P_A_dat_B = nrow(AB_df) / nrow(B_df),
        P_B_dat_A = nrow(AB_df) / sum(date$A)))
print(prop.table(tabel, margin = 1))

mosaicplot(tabel, color = c("#D9B6CD", "#A33278"),
           main = "Promovarea in cele doua grupuri",
           xlab = "Gen", ylab = "Promovat", las = 1)
if (interactive()) View(B_df)
